create view kan_levere as
  select `oving11`.`prisinfo`.`levnr`                                      AS `levnr`,
         `oving11`.`ordredetalj`.`delnr`                                   AS `delnr`,
         `oving11`.`prisinfo`.`pris`                                       AS `pris`,
         (`oving11`.`prisinfo`.`pris` * `oving11`.`ordredetalj`.`kvantum`) AS `pris*kvantum`
  from `oving11`.`prisinfo`
         join `oving11`.`ordredetalj`
  where ((`oving11`.`prisinfo`.`delnr` = `oving11`.`ordredetalj`.`delnr`) and (`oving11`.`ordredetalj`.`ordrenr` = 18));

