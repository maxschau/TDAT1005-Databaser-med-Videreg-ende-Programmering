create view res_23_mai as
  select `eks_2019`.`reservasjon`.`romid` AS `romid`
  from `eks_2019`.`reservasjon`
  where (`eks_2019`.`reservasjon`.`dato` = ((2019 - 3) - 23));

