create view antall_res as
  select `eks_2019`.`rom`.`romnavn` AS `romnavn`, count(0) AS `antall_res`
  from (`eks_2019`.`rom` join `eks_2019`.`reservasjon` on ((`eks_2019`.`rom`.`romid` =
                                                            `eks_2019`.`reservasjon`.`romid`)))
  group by `eks_2019`.`rom`.`romnavn`;

