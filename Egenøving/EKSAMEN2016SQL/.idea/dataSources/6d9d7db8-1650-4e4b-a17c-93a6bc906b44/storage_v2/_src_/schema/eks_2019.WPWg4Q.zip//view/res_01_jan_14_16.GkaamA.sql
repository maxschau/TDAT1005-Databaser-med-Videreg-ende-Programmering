create view res_01_jan_14_16 as
  select `eks_2019`.`rom`.`romnavn` AS `romnavn`
  from (`eks_2019`.`rom` left join `eks_2019`.`reservasjon` on ((`eks_2019`.`rom`.`romid` =
                                                                 `eks_2019`.`reservasjon`.`romid`)))
  where ((`eks_2019`.`reservasjon`.`dato` = '2019-01-01') and
         ((`eks_2019`.`reservasjon`.`fra_tid` between '14:00' and '16:00') or
          (`eks_2019`.`reservasjon`.`til_tid` between '14:00' and '16:00')));

