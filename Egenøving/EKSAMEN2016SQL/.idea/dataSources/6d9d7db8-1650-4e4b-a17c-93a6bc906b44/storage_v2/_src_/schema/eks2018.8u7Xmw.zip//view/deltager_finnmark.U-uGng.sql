create view deltager_finnmark as
  select `eks2018`.`deltaker`.`deltnr`           AS `deltnr`,
         count(`eks2018`.`tidtaking`.`fullfort`) AS `count(tidtaking.fullfort)`,
         `eks2018`.`tidtaking`.`tid`             AS `tid`
  from (((`eks2018`.`deltaker` join `eks2018`.`tidtaking` on ((`eks2018`.`deltaker`.`deltnr` =
                                                               `eks2018`.`tidtaking`.`deltnr`))) join `eks2018`.`lop_etappe` on ((
    `eks2018`.`tidtaking`.`lnr` = `eks2018`.`lop_etappe`.`lnr`))) join `eks2018`.`lop` on ((`eks2018`.`lop`.`lnr` =
                                                                                            `eks2018`.`lop_etappe`.`lnr`)))
  where ((`eks2018`.`lop`.`lopsnavn` = 'Finnmarkslopet') and (`eks2018`.`lop`.`aar` = 2018));

