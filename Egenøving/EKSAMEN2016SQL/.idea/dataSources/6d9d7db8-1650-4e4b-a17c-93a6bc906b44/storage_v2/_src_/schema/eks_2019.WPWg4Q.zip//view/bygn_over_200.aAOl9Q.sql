create view bygn_over_200 as
  select `eks_2019`.`bygning`.`bygnnavn` AS `bygnnavn`, sum(`eks_2019`.`romtype`.`ant_personer`) AS `ant_personer_bygg`
  from ((`eks_2019`.`bygning` join `eks_2019`.`rom` on ((`eks_2019`.`bygning`.`bygnnavn` =
                                                         `eks_2019`.`rom`.`bygnnavn`))) join `eks_2019`.`romtype` on ((
    `eks_2019`.`rom`.`typeid` = `eks_2019`.`romtype`.`typeid`)))
  group by `eks_2019`.`bygning`.`bygnnavn`
  having (`ant_personer_bygg` > 200);

